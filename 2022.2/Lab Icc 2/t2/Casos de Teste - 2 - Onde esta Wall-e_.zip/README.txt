Arquivo zip gerado em: 01/10/2022 22:50:54 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 2 - Onde está Wall-e?